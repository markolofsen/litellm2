# LiteLLM2

A powerful and flexible AI agent framework with LLM integration capabilities and tool support.

## Overview

LiteLLM2 provides a comprehensive framework for working with LLMs and creating AI agents with various capabilities:

- Structured LLM client integration with multiple providers
- Typesafe response handling with Pydantic models
- Budget management and caching for cost control
- Advanced agent system with built-in tool integration

## Installation

```bash
pip install litellm2
```

## Prerequisites

Before using LiteLLM2, you need to set up your API key:

```bash
# In your .env file
OPENROUTER_API_KEY=your_api_key_here
```

Or set it as an environment variable:

```bash
export OPENROUTER_API_KEY=your_api_key_here
```

## Working with LLMs

LiteLLM2's primary functionality is structured interaction with language models through the `LiteLLMClient` class.

### Basic LLM Usage

```python
from src.litellm2 import Request, LiteLLMClient

# Configure the client
config = Request(
    temperature=0.7,
    max_tokens=500,
    model="openrouter/openai/gpt-4o-mini",
    online=True,  # Set to True for real API calls
)

# Initialize client
client = LiteLLMClient(config)

# Add a message
client.msg.add_message_user("What is the capital of France?")

# Generate response
response = client.generate_response()
print(response)
```

### Structured Responses with Pydantic

You can define custom response models for structured output:

```python
from pydantic import Field
from typing import List, Optional

from src.litellm2 import Request, LiteLLMClient
from drf_pydantic import BaseModel


class CustomAnswer(BaseModel):
    """Example custom answer model."""
    content: str = Field(..., description="The main content")
    keywords: List[str] = Field(default_factory=list, description="Keywords extracted from the response")
    sentiment: Optional[str] = Field(None, description="Sentiment analysis")


def main():
    # Create client with default configuration and custom answer model
    config = Request(
        temperature=0.7,
        max_tokens=500,
        model="openrouter/openai/gpt-4o-mini",
        online=False,
        cache_prompt=True,
        budget_limit=0.05,
        answer_model=CustomAnswer,
        verbose=True,
        logs=True,
    )

    # Initialize typed client with CustomAnswer
    client = LiteLLMClient(config)

    # Add a message
    client.msg.add_message_user("""
        You are a helpful assistant that can answer questions and help with tasks.
        You are given a question and you need to answer it.
        You are also given a list of keywords and you need to use them to answer the question.
        You are also given a sentiment and you need to use it to answer the question.
        You are also given a content and you need to use it to answer the question.
    """)

    try:
        # Generate response
        response: CustomAnswer = client.generate_response()

        # Print current response details
        print('Meta:', client.meta.model_dump())
        print('Request:', client.config.model_dump())

        if response is not None:
            print('Response:', response.sentiment)
        else:
            print('Error: Failed to generate response')

    except Exception as e:
        print(f'Error: {str(e)}')


if __name__ == "__main__":
    main()
```

### Configuration Options

LiteLLM2 supports various configuration options through the `Request` class:

- `temperature`: Controls randomness (0.0 to 1.0)
- `max_tokens`: Maximum tokens in the response
- `model`: Model identifier to use
- `online`: Whether to make actual API calls or use cached responses
- `cache_prompt`: Whether to cache prompts
- `budget_limit`: Maximum budget for API calls
- `answer_model`: Pydantic model for structured responses
- `verbose`: Enable verbose logging
- `logs`: Enable logging to file

## Working with Agents

LiteLLM2 includes a robust agent system that extends the basic LLM capabilities with tools and advanced functionality.

### Agent Types

The module includes two primary agent implementations:

- `SimpleAgent`: Base agent implementation with core functionality
- `AdvancedAgent`: Extended agent with additional built-in tools

### Using the AdvancedAgent

```python
from src.litellm2.agents import AdvancedAgent

# Create an agent instance
agent = AdvancedAgent()

# Run the agent
result = agent.run("What is the current date and time?")
print(result)

# Optional: Run the demo with Gradio UI
agent.run_demo()
```

### Available Tools

The AdvancedAgent comes with several built-in tools out of the box:

**Date and Time Tools**
- `date_time`: Get current date and time in specified format
- `timestamp`: Get current Unix timestamp

**Math Tools**
- `random_number`: Generate random numbers within a range
- `calculate`: Evaluate mathematical expressions

**Text Processing Tools**
- `word_count`: Count words in text
- `reverse_text`: Reverse input text
- `text_stats`: Get statistics about text (characters, words, etc.)

**Utility Tools**
- `echo`: Echo back input text
- `help_info`: Get help information about topics
- `weather_api`: Get simulated weather information for a city

### Custom Tools

You can extend agents with your own custom tools:

```python
from src.litellm2.agents import SimpleAgent
from src.litellm2.utils.tools import Tool

# Define a custom tool
def my_custom_tool(input_text: str) -> str:
    """A tool that does something with input_text"""
    return f"Processed: {input_text.upper()}"

# Create agent with custom tool
agent = SimpleAgent()
agent.add_tool(Tool(
    name="custom_processor",
    description="Processes text in a custom way",
    func=my_custom_tool
))

# Use the agent with the custom tool
result = agent.run("Use custom_processor with this text")
print(result)
```

## License

MIT License - see the LICENSE file for details.
